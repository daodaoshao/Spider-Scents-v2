<?php
if( !isset($gCms) ) exit;

?>