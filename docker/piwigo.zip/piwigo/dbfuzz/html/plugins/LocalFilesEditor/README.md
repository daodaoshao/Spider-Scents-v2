# Piwigo LocalFilesEditor

* Internal name: `LocalFilesEditor` (directory name in `plugins/`)
* Plugin page: http://piwigo.org/ext/extension_view.php?eid=144
* Translation: http://piwigo.org/translate/project.php?project=localfileseditor
