# Piwigo LanguageSwitch

* Internal name: `language_switch` (directory name in `plugins/`)
* Plugin page: http://piwigo.org/ext/extension_view.php?eid=123
